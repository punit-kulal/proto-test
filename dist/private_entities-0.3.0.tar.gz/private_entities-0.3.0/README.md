

FAQ

#### Reason for python files to be *_pb2.py
- https://github.com/grpc/grpc/issues/15444#issuecomment-396442980. TLDR, it's not based on protobuf version but protobuf python API version